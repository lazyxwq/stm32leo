var struct_s_cn_s_c_b___type =
[
    [ "ACTLR", "struct_s_cn_s_c_b___type.html#a13af9b718dde7481f1c0344f00593c23", null ],
    [ "ICTR", "struct_s_cn_s_c_b___type.html#a34ec1d771245eb9bd0e3ec9336949762", null ],
    [ "RESERVED0", "struct_s_cn_s_c_b___type.html#afe1d5fd2966d5062716613b05c8d0ae1", null ]
];